# Cirurgia Robótica VR — protótipo educativo

Este repositório contém um protótipo web 3D para Meta Quest 3S, pensado para uma feira de ciências.

## O que existe nesta versão
- Ambiente 3D com mesa de treino e braço robótico articulado.
- Seleção de junta: base, ombro, cotovelo e punho.
- Controle por analógicos dos controles VR; botão A/X troca a junta selecionada.
- Gatilho abre/fecha a pinça.
- Desafio fictício com alvo e pontuação.
- Teclas para teste fora do VR: `1`/`2` trocam a junta, setas movem, espaço abre/fecha a pinça e `R` reinicia.

## Como publicar pelo GitHub no celular
1. Extraia o ZIP no celular.
2. Abra o repositório `cirurgia-robótica-vr`.
3. Use **Add file / Adicionar arquivo → Upload files / Carregar arquivos**.
4. Envie `index.html` e `README.md` (não envie o ZIP como se fosse o site).
5. Faça o commit.
6. Em **Settings → Pages**, selecione a branch `principal` (ou `main`, conforme o nome exibido) e a pasta `/ (root)`.
7. Aguarde o GitHub Pages publicar o site. O endereço costuma ser `https://SEU-USUARIO.github.io/cirurgia-robótica-vr/`.

## Como abrir
Abra o endereço publicado no navegador do Meta Quest 3S e use o botão de VR do navegador para entrar no modo imersivo. Também é possível abrir no celular para conferir a página, mas o modo VR exige um navegador/dispositivo compatível com WebXR.

## Observações importantes
- Esta é uma primeira versão de protótipo; ainda precisa ser testada no Meta Quest 3S real.
- A cena usa A-Frame carregado de uma CDN, então precisa de conexão com a internet.
- O treino é inteiramente fictício e educativo. Não representa cirurgia real, não contém instruções médicas e não deve ser usado para treinamento clínico.
